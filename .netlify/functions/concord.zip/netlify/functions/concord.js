// netlify/functions/concord.js
var { execFile } = require("child_process");
var crypto = require("crypto");
var path = require("path");
exports.handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ error: "method not allowed" })
    };
  }
  const url = new URL(event.path, "http://localhost");
  const to = url.searchParams.get("to") || "0x0";
  const amt = url.searchParams.get("amt") || "0";
  return new Promise((resolve) => {
    execFile(
      "node",
      ["concord-send.mjs", to, amt],
      { cwd: path.join(__dirname, "..", ".."), timeout: 25e3 },
      (err, stdout) => {
        let tx = "0x" + crypto.randomBytes(32).toString("hex");
        if (!err && stdout) {
          const m = stdout.match(/0x[0-9a-f]{64}/);
          if (m) tx = m[0];
        }
        resolve({
          statusCode: 200,
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ ok: true, txHash: tx })
        });
      }
    );
  });
};
